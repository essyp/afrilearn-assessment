import React, { Component, Fragment } from 'react';
import $ from 'jquery';
import { Link } from "react-router-dom";

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      base_url: this.props.base_url,
      api_url: this.props.api_url,
    }
  }
  
  render() {
    return (
        <Fragment>
            <div className="top-bar-area address-two-lines bg-dark text-light">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8 address-info">
                            <div className="info box">
                                <ul>
                                    <li>
                                        <span><i className="fas fa-map"></i> Address</span>California, TX 70240
                                    </li>
                                    <li>
                                        <span><i className="fas fa-envelope-open"></i> Email</span>Info@gmail.com
                                    </li>
                                    <li>
                                        <span><i className="fas fa-phone"></i> Contact</span>+123 456 7890
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="user-login text-right col-md-4">
                            <a className="popup-with-form" href="#register-form">
                                <i className="fas fa-edit"></i> Register
                            </a>
                            <a  className="popup-with-form" href="#login-form">
                                <i className="fas fa-user"></i> Login
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <header id="home">
                
                <nav className="navbar navbar-default navbar-sticky bootsnav">
                    
                    <div className="container">
                        <div className="row">
                            <div className="top-search">
                                <div className="input-group">
                                    <form action="#">
                                        <input type="text" name="text" className="form-control" placeholder="Search" />
                                        <button type="submit">
                                            <i className="fas fa-search"></i>
                                        </button>  
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div className="container">
        
        
                        <div className="attr-nav">
                            <ul>
                                <li className="search"><a href="#"><i className="fa fa-search"></i></a></li>
                            </ul>
                        </div>        
                        
                        <div className="navbar-header">
                            <button type="button" className="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                                <i className="fa fa-bars"></i>
                            </button>
                            <a className="navbar-brand" href="index">
                                <img src="assets/img/logo.png" className="logo" alt="Logo" />
                            </a>
                        </div>
                        
                        <div className="collapse navbar-collapse" id="navbar-menu">
                            <ul className="nav navbar-nav navbar-right" data-in="#" data-out="#">
                                <li className="dropdown">
                                    <a href="#" className="dropdown-toggle active" data-toggle="dropdown" >Home</a>
                                    <ul className="dropdown-menu">
                                        <li><Link to="/">Home Version One</Link></li>
                                        <li><Link to="index-2">Home Version Two</Link></li>
                                        <li><Link to="index-3">Home Version Three</Link></li>
                                        <li><Link to="index-4">Home Version Four</Link></li>
                                        <li><Link to="index-5">Home Version Five</Link></li>
                                        <li><Link to="index-6">Home Version Six</Link></li>
                                        <li><Link to="index-7">Home Version Serven <span className="badge">New</span></Link></li>
                                        <li><Link to="index-onepage">Onepage Version One</Link></li>
                                        <li><Link to="index-2-onepage">Onepage Version Two</Link></li>
                                        <li><Link to="index-3-onepage">Onepage Version Three</Link></li>
                                        <li><Link to="index-4-onepage">Onepage Version Four</Link></li>
                                        <li><Link to="index-5-onepage">Onepage Version Five</Link></li>
                                        <li><Link to="index-6-onepage">Onepage Version Six</Link></li>
                                    </ul>
                                </li>
                                <li className="dropdown megamenu-fw">
                                    <a href="#" className="dropdown-toggle" data-toggle="dropdown">Pages</a>
                                    <ul className="dropdown-menu megamenu-content" role="menu">
                                        <li>
                                            <div className="row">
                                                <div className="col-menu col-md-3">
                                                    <h6 className="title">Gallery</h6>
                                                    <div className="content">
                                                        <ul className="menu-col">
                                                            <li><Link to="gallery-2-colum">Gallery Two Colum</Link></li>
                                                            <li><Link to="gallery-3-colum">Gallery Three Colum</Link></li>
                                                            <li><Link to="gallery-4-colum">Gallery Four Colum</Link></li>
                                                            <li><Link to="gallery-6-colum">Gallery Six Colum</Link></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div className="col-menu col-md-3">
                                                    <h6 className="title">Advisor</h6>
                                                    <div className="content">
                                                        <ul className="menu-col">
                                                            <li><Link to="advisor-carousel">Advisor Carousel</Link></li>
                                                            <li><Link to="advisor-2-colum">Advisor Two Colum</Link></li>
                                                            <li><Link to="advisor-3-colum">Advisor Three Colum</Link></li>
                                                            <li><Link to="advisor-carousel-2">Advisor Carousel Two</Link></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div className="col-menu col-md-3">
                                                    <h6 className="title">User Pages</h6>
                                                    <div className="content">
                                                        <ul className="menu-col">
                                                            <li><Link to="profile">Profile</Link></li>
                                                            <li><Link to="edit-profile">Edit Profile</Link></li>
                                                            <li><Link to="login">login</Link></li>
                                                            <li><Link to="register">register</Link></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div className="col-menu col-md-3">
                                                    <h6 className="title">Other Pages</h6>
                                                    <div className="content">
                                                        <ul className="menu-col">
                                                            <li><Link to="about-us">About Us</Link></li>
                                                            <li><Link to="faq">Faq</Link></li>
                                                            <li><Link to="pricing-table">Pricing Table</Link></li>
                                                            <li><Link to="contact">Contact</Link></li>
                                                            <li><Link to="404">Error Page</Link></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li className="dropdown">
                                    <a href="#" className="dropdown-toggle active" data-toggle="dropdown" >Courses</a>
                                    <ul className="dropdown-menu">
                                        <li><Link to="courses">Courses Carousel One</Link></li>
                                        <li><Link to="courses-2">Courses Grid One</Link></li>
                                        <li><Link to="courses-3">Courses Grid Two</Link></li>
                                        <li><Link to="courses-4">Courses Carousel Two</Link></li>
                                        <li><Link to="course-details">Course Details</Link></li>
                                    </ul>
                                </li>
                                <li className="dropdown">
                                    <a href="#" className="dropdown-toggle active" data-toggle="dropdown" >Teachers</a>
                                    <ul className="dropdown-menu">
                                        <li><Link to="teachers">Advisor</Link></li>
                                        <li><Link to="teachers-details">Advisor Details</Link></li>
                                    </ul>
                                </li>
                                <li className="dropdown">
                                    <a href="#" className="dropdown-toggle active" data-toggle="dropdown" >Event</a>
                                    <ul className="dropdown-menu">
                                        <li><Link to="event">Event Mixed Colum</Link></li>
                                        <li><Link to="event-2">Event Grid Colum</Link></li>
                                        <li><Link to="event-3">Event Carousel</Link></li>
                                    </ul>
                                </li>
                                <li className="dropdown">
                                    <a href="#" className="dropdown-toggle" data-toggle="dropdown" >Blog</a>
                                    <ul className="dropdown-menu">
                                        <li><Link to="blog-standard">Blog Standard</Link></li>
                                        <li><Link to="blog-left-sidebar">Blog Left Sidebar</Link></li>
                                        <li><Link to="blog-right-sidebar">Blog Right Sidebar</Link></li>
                                        <li><Link to="blog-single-standard">Single Standard</Link></li>
                                        <li><Link to="blog-single-left-sidebar">Single Left Sidebar</Link></li>
                                        <li><Link to="blog-single-right-sidebar">Single Right Sidebar</Link></li>
                                    </ul>
                                </li>
                                <li>
                                    <Link to="contact">contact</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
        
                </nav>
                
        
            </header>
            
            <form action="#" id="login-form" className="mfp-hide white-popup-block">
                <div className="col-md-4 login-social">
                    <h4>Login with social</h4>
                    <ul>
                        <li className="facebook">
                            <a href="#">
                                <i className="fab fa-facebook-f"></i>
                            </a>
                        </li>
                        <li className="twitter">
                            <a href="#">
                                <i className="fab fa-twitter"></i>
                            </a>
                        </li>
                        <li className="linkedin">
                            <a href="#">
                                <i className="fab fa-linkedin-in"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div className="col-md-8 login-custom">
                    <h4>login to your registered account!</h4>
                    <div className="col-md-12">
                        <div className="row">
                            <div className="form-group">
                                <input className="form-control" placeholder="Email*" type="email" />
                            </div>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="row">
                            <div className="form-group">
                                <input className="form-control" placeholder="Password*" type="text" />
                            </div>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="row">
                            <label htmlFor="login-remember"><input type="checkbox" id="login-remember" />Remember Me</label>
                            <a title="Lost Password" href="#" className="lost-pass-link">Lost your password?</a>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div className="row">
                            <button type="submit">
                                Login
                            </button>
                        </div>
                    </div>
                    <p className="link-bottom">Not a member yet? <a href="#">Register now</a></p>
                </div>
            </form>
        
            <form action="#" id="register-form" className="mfp-hide white-popup-block">
            <div className="col-md-4 login-social">
                <h4>Register with social</h4>
                <ul>
                    <li className="facebook">
                        <a href="#">
                            <i className="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li className="twitter">
                        <a href="#">
                            <i className="fab fa-twitter"></i>
                        </a>
                    </li>
                    <li className="linkedin">
                        <a href="#">
                            <i className="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div className="col-md-8 login-custom">
                <h4>Register a new account</h4>
                <div className="col-md-12">
                    <div className="row">
                        <div className="form-group">
                            <input className="form-control" placeholder="Email*" type="email" />
                        </div>
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="row">
                        <div className="form-group">
                            <input className="form-control" placeholder="Username*" type="text" />
                        </div>
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="row">
                        <div className="form-group">
                            <input className="form-control" placeholder="Password*" type="text" />
                        </div>
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="row">
                        <div className="form-group">
                            <input className="form-control" placeholder="Repeat Password*" type="text" />
                        </div>
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="row">
                        <button type="submit">
                            Sign up
                        </button>
                    </div>
                </div>
                <p className="link-bottom">Are you a member? <a href="#">Login now</a></p>
            </div>
        </form>
        </Fragment>
    );
  }
}

export default Header;