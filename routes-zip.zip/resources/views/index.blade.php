@extends( 'layouts.app' )

@section('title','Online learning platform')

@section('style')
@endsection

@section('content')

    <div id="root"></div>
  
@endsection

@section('script')
@endsection