<?php $__env->startSection('title','Online learning platform'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/waitMe.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="root"></div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/waitMe.min.js')); ?>"></script>
    <script>
        function open_loader(container) {
			$(container).waitMe({
				effect : 'bounce',
				text : '',
				bg : 'rgba(255,255,255,0.7)',
				color : '#000',
				maxSize : '',
				waitTime : '-1',
				textPos : 'vertical',
				fontSize : '',
				source : '',
				onClose : function() {}
			});
		}

		function close_loader(container) {
			$(container).waitMe("hide");
		}
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.app' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrilearn3\resources\views/index.blade.php ENDPATH**/ ?>