<?php $__env->startSection('title','Online learning platform'); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div id="home"></div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- <script src="<?php echo e(asset('js/app.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.app' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrilearn\resources\views/index.blade.php ENDPATH**/ ?>